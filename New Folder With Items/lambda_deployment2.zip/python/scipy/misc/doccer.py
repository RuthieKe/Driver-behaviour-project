import warnings
warnings.warn(
    "scipy.misc.doccer is deprecated and will be removed in 2.0.0",
    DeprecationWarning,
    stacklevel=2
)
